/*
 * (C) Copyright 2004 by Autodesk, Inc. All Rights Reserved.
 *
 * By using this code, you are agreeing to the terms and conditions of
 * the License Agreement included in the documentation for this code.
 *
 * AUTODESK MAKES NO WARRANTIES, EXPRESS OR IMPLIED, AS TO THE
 * CORRECTNESS OF THIS CODE OR ANY DERIVATIVE WORKS WHICH INCORPORATE
 * IT. AUTODESK PROVIDES THE CODE ON AN "AS-IS" BASIS AND EXPLICITLY
 * DISCLAIMS ANY LIABILITY, INCLUDING CONSEQUENTIAL AND INCIDENTAL
 * DAMAGES FOR ERRORS, OMISSIONS, AND OTHER PROBLEMS IN THE CODE.
 *
 * Use, duplication, or disclosure by the U.S. Government is subject
 * to restrictions set forth in FAR 52.227-19 (Commercial Computer
 * Software Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
 * (Rights in Technical Data and Computer Software), as applicable.
 *
 * Revision Control Modification History
 *
 *         $Id: //Providers/RasterFile/src/UnitTest/RfpTestNITF.cpp#1 $
 *     $Author: miaoya $
 *   $DateTime: 2005/03/17 19:58:08 $
 *     $Change: 6738 $
 *
 */

#include <UnitTest.h>
#include <RfpTestNITF.h>

RfpTestNITF::RfpTestNITF()
{
}

RfpTestNITF::~RfpTestNITF()
{
}

void RfpTestNITF::_setUp()
{
}

void RfpTestNITF::_tearDown()
{
}

/// 
/// From DDigital Globe (Satellite Vendor) 
/// 4 frames:  IREP=MULTI	 ICAT=MS	DataModel=Data	 Bpp=16	 UsedBpp=11	 
/// 
void RfpTestNITF::testDigitalGlobe()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testDigitalGlobe()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	connection->SetConnectionString(L"DefaultRasterFileLocation=TestData/NITF/DigitalGlobe");
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"default:default");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"default:default.Raster");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 4);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();	
	CPPUNIT_ASSERT(1552 == xSize);
	CPPUNIT_ASSERT(973 == ySize);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 16);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Data);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());

	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (973 - 1) / tileSizeX + 1;
	int numTileCols = (1552 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 2;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(60);
	raster->SetImageYSize(60);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	

	// iterate all rows
	FdoByte buff[120]; //60*2
	for (int row = 0; row < 60; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 120);
		CPPUNIT_ASSERT(numRead == 120);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}


/// 
/// Space Imaging (Satellite Vendor)
/// 1 frame:  IREP=MONO	 ICAT=MS	 DataModel=Data	 Bpp=16	 UsedBpp=11	
/// 
void RfpTestNITF::testSpaceImaging1()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testSpaceImaging1()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	connection->SetConnectionString(L"DefaultRasterFileLocation=TestData/NITF/SpaceImaging/po_140244_blu_0000000.ntf");
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"default:default");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"default:default.Raster");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 1);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 251);
	CPPUNIT_ASSERT(ySize == 251);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 16);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Data);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (251 - 1) / tileSizeX + 1;
	int numTileCols = (251 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 2;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(100);
	raster->SetImageYSize(100);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());

	// iterate all rows
	FdoByte buff[200]; //1800*2
	for (int row = 0; row < 100; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 200);
		CPPUNIT_ASSERT(numRead == 200);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}

/// 
/// Space Imaging (Satellite Vendor)
/// 1 frame:   IREP=MONO	 ICAT=VIS	 DataModel=Data	 Bpp=16	 UsedBpp=11	
/// 
void RfpTestNITF::testSpaceImaging2()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testSpaceImaging2()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	connection->SetConnectionString(L"DefaultRasterFileLocation=TestData/NITF/SpaceImaging/po_140244_pan_0000000.ntf");
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"default:default");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"default:default.Raster");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 1);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 1004);
	CPPUNIT_ASSERT(ySize == 1004);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 16);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Data);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (1004 - 1) / tileSizeX + 1;
	int numTileCols = (1004 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 2;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(500);
	raster->SetImageYSize(500);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());

	// iterate all rows
	FdoByte buff[1000]; //500*2
	for (int row = 0; row < 500; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 1000);
		CPPUNIT_ASSERT(numRead == 1000);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}

/// 
/// From NGA (Standard)
/// 1 frame:   IREP=MONO	 ICAT=VIS	 DataModel=Gray	 Bpp=8	 UsedBpp=8	
/// 
void RfpTestNITF::testNGA1()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testNGA1()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	connection->SetConnectionString(L"DefaultRasterFileLocation=TestData/NITF/NGA/U_1001A.NTF");
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"default:default");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"default:default.Raster");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 1);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 1024);
	CPPUNIT_ASSERT(ySize == 1024);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 8);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Gray);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (1024 - 1) / tileSizeX + 1;
	int numTileCols = (1024 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 1;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(504);
	raster->SetImageYSize(504);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());

	// iterate all rows
	FdoByte buff[504]; //500*1
	for (int row = 0; row < 504; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 504);
		CPPUNIT_ASSERT(numRead == 504);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}

/// 
/// From NGA (Standard)
/// 1 frame:    IREP=YCbCr601	 ICAT=VIS	 DataModel=Rgb	 Bpp=32	 Used Bpp=24	
/// 
void RfpTestNITF::testNGA2()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestDted::testNGA2()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	FdoPtr<FdoIoStream> stream = FdoIoFileStream::Create(L"TestData/NITF/NGA/U_2020A.xml", L"r");
	connection->SetConfiguration(stream);
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"Photo");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"Image");
    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 256);
	CPPUNIT_ASSERT(ySize == 256);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 32);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_RGBA);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (256 - 1) / tileSizeX + 1;
	int numTileCols = (256 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 4;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(100);
	raster->SetImageYSize(100);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	

	// iterate all rows
	FdoByte buff[400]; //100*4
	for (int row = 0; row < 100; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 400);
		CPPUNIT_ASSERT(numRead == 400);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}


/// 
/// From NGA (Standard)
/// 1 frame:    IREP=RGB/LUT	 ICAT=VIS	 DataModel=PalettedRgb	 Bpp=8	 UsedBpp=8	
/// 
void RfpTestNITF::testNGA3()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testNGA3()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	FdoPtr<FdoIoStream> stream = FdoIoFileStream::Create(L"TestData/NITF/NGA/U_2001A.xml", L"r");
	connection->SetConfiguration(stream);
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"Photo");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"Image");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 1);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 487);
	CPPUNIT_ASSERT(ySize == 347);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 8);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Palette);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (487 - 1) / tileSizeX + 1;
	int numTileCols = (347 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 1;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(200);
	raster->SetImageYSize(150);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());

	// iterate all rows
	FdoByte buff[200]; //200*1
	for (int row = 0; row < 150; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 200);
		CPPUNIT_ASSERT(numRead == 200);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}

/// 
/// From NGA (Standard)
/// 1 frame:    IREP=YCbCr601	 ICAT=VIS	 DataModel=Rgb	 Bpp=32	 Used Bpp=24	
/// 
void RfpTestNITF::testNGA4()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestDted::testNGA4()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	FdoPtr<FdoIoStream> stream = FdoIoFileStream::Create(L"TestData/NITF/NGA/U_2001D.xml", L"r");
	connection->SetConfiguration(stream);
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"Photo");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"Image");
    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 256);
	CPPUNIT_ASSERT(ySize == 256);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 32);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_RGBA);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (256 - 1) / tileSizeX + 1;
	int numTileCols = (256 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 4;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(100);
	raster->SetImageYSize(100);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	

	// iterate all rows
	FdoByte buff[400]; //100*4
	for (int row = 0; row < 100; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 400);
		CPPUNIT_ASSERT(numRead == 400);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}

/// 
/// From NGA (Standard)
/// 4 frames:     IREP=MONO	 ICAT=VIS	 DataModel=Gray	 Bpp=8	 Used Bpp=8		
/// 
void RfpTestNITF::testNGA5()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testNGA5()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	FdoPtr<FdoIoStream> stream = FdoIoFileStream::Create(L"TestData/NITF/NGA/U_1123A.xml", L"r");
	connection->SetConfiguration(stream);
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"Photo");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"Image");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 1);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 1024);
	CPPUNIT_ASSERT(ySize == 1024);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 8);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Gray);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (1024 - 1) / tileSizeX + 1;
	int numTileCols = (1024 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 1;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(512);
	raster->SetImageYSize(512);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());

	// iterate all rows
	FdoByte buff[512]; //512*1
	for (int row = 0; row < 512; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 512);
		CPPUNIT_ASSERT(numRead == 512);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}

/// 
/// From NGA (Standard)
/// 1 frame:     IREP=RGB/LUT	 ICAT=MAP	 DataModel=PalettedRgb	 Bpp=8	 Used Bpp=8		
/// 
void RfpTestNITF::testNGA6()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testNGA6()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	connection->SetConnectionString(L"DefaultRasterFileLocation=TestData/NITF/NGA/U_3058B.NTF");
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"default:default");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"default:default.Raster");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 1);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 1536);
	CPPUNIT_ASSERT(ySize == 1536);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 8);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Palette);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (1536 - 1) / tileSizeX + 1;
	int numTileCols = (1536 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 1;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(512);
	raster->SetImageYSize(512);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());

	// iterate all rows
	FdoByte buff[512]; //512*1
	for (int row = 0; row < 512; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 512);
		CPPUNIT_ASSERT(numRead == 512);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();
}

/// 
/// From NGA (Standard)
/// 1 frame:      IREP=MONO	 ICAT=VIS	 DataModel=Data	 Bpp=32	 Used Bpp=32			
/// 
void RfpTestNITF::testNGA7()
{
    wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testNGA7()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	FdoPtr<FdoIoStream> stream = FdoIoFileStream::Create(L"TestData/NITF/NGA/i_3450c.xml", L"r");
	connection->SetConfiguration(stream);
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_Select);
	FdoPtr<FdoISelect> cmdSelect = static_cast<FdoISelect*>(cmd);
	cmdSelect->SetFeatureClassName(L"Photo");
	FdoPtr<FdoIFeatureReader> featureReader = cmdSelect->Execute();

	CPPUNIT_ASSERT(featureReader->ReadNext());

	FdoPtr<FdoIRaster> raster = featureReader->GetRaster(L"Image");

	FdoInt32 nNumOfBands = raster->GetNumberOfBands();
	CPPUNIT_ASSERT(nNumOfBands == 1);

    FdoInt32 xSize = raster->GetImageXSize();
    FdoInt32 ySize = raster->GetImageYSize();
	CPPUNIT_ASSERT(xSize == 1024);
	CPPUNIT_ASSERT(ySize == 512);

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 32);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Data);

	CPPUNIT_ASSERT(dataModel->GetTileSizeX() == raster->GetImageXSize());
	CPPUNIT_ASSERT(dataModel->GetTileSizeY() == raster->GetImageYSize());
	// retiling
	const FdoInt32 tileSizeX = 128, tileSizeY = 128;
	dataModel->SetTileSizeX(tileSizeX);
	dataModel->SetTileSizeY(tileSizeY);
	raster->SetDataModel(dataModel);

	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());	
	int numTileRows = (1024 - 1) / tileSizeX + 1;
	int numTileCols = (512 - 1) / tileSizeY + 1;
	const int bytesTile = tileSizeX * tileSizeY * 4;

	FdoByte* buffer = new FdoByte[bytesTile];
	for (int i = 0; i < numTileRows; i++)
	{
		// read the first tile of the tile row
		FdoInt32 numRead = reader->ReadNext(buffer, 0, bytesTile);
		CPPUNIT_ASSERT(numRead == bytesTile);
		// skip the rest tiles
		reader->Skip(bytesTile * (numTileCols - 1));
	}
    
	// no data
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);
	delete[] buffer;

	// scale down to 1/2 of original size and read it row by row
	raster->SetImageXSize(512);
	raster->SetImageYSize(218);
	dataModel->SetTileSizeX(raster->GetImageXSize());
	dataModel->SetTileSizeY(raster->GetImageYSize());
	raster->SetDataModel(dataModel);
	reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(raster->GetStreamReader());

	// iterate all rows
	FdoByte buff[512*4]; //512*4
	for (int row = 0; row < 218; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buff, 0, 512*4);
		CPPUNIT_ASSERT(numRead == 512*4);
	}
	CPPUNIT_ASSERT(reader->ReadNext(buff, 0, 1) == 0);

	connection->Close();

}

#define orgX 0.0
#define orgY 0.0

/// 
/// Test Clip and Mosaic on kDataModel
/// 
void RfpTestNITF::testClippedMosaic_Data()
{
	wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testClippedMosaic_Data()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	FdoPtr<FdoIoStream> stream = FdoIoFileStream::Create(L"TestData/NITF/nitf_filters_data.xml", L"r");
	connection->SetConfiguration(stream);
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_SelectAggregates);
	FdoPtr<FdoISelectAggregates> cmdSelect = static_cast<FdoISelectAggregates*>(cmd);
	cmdSelect->SetFeatureClassName(L"Photo");
	FdoPtr<FdoFilter> filter = FdoRfpUtil::CreateSpatialCondition(L"Image", 
		FdoSpatialOperations_Intersects, 
		FdoRfpRect(orgX + 50, orgY + 50, orgX + 1200, orgY + 1200));
	cmdSelect->SetFilter(filter);

	FdoPtr<FdoIdentifierCollection> propsToSelect = cmdSelect->GetPropertyNames();

	// set up clip function: CLIP(Image, orgX + 50, orgY + 50, orgX + 1000.0, orgY + 1000.0)
	FdoPtr<FdoExpressionCollection> funcParams = FdoExpressionCollection::Create();
	FdoPtr<FdoIdentifier> rasterProp = FdoIdentifier::Create(L"Image");
	funcParams->Add(rasterProp);
	FdoPtr<FdoDataValue> minX = FdoDataValue::Create(orgX + 50, FdoDataType_Double);
	funcParams->Add(minX);
	FdoPtr<FdoDataValue> minY = FdoDataValue::Create(orgY + 50, FdoDataType_Double);
	funcParams->Add(minY);
	FdoPtr<FdoDataValue> maxX = FdoDataValue::Create(orgX + 1200, FdoDataType_Double);
	funcParams->Add(maxX);
	FdoPtr<FdoDataValue> maxY = FdoDataValue::Create(orgY + 1200, FdoDataType_Double);
	funcParams->Add(maxY);
	FdoPtr<FdoFunction> clipFunc = FdoFunction::Create(L"CLIP", funcParams);
	FdoPtr<FdoComputedIdentifier> clipIdentifier = FdoComputedIdentifier::Create(L"clippedRaster", clipFunc );

	// create the nested MOSAIC function that contains CLIP function
	funcParams = FdoExpressionCollection::Create();
	funcParams->Add(clipFunc); // you could add either clipFunc or clipIdentifier here
	FdoPtr<FdoFunction> mosaicFunc = FdoFunction::Create(L"MOSAIC", funcParams);
	FdoPtr<FdoComputedIdentifier> mosaicIdentifier = FdoComputedIdentifier::Create(L"stitchedRaster", mosaicFunc );
	// add it to the properties to select
	propsToSelect->Add(mosaicIdentifier);
	FdoPtr<FdoIDataReader> dataReader = cmdSelect->Execute();

	
	CPPUNIT_ASSERT( dataReader->ReadNext() == true);
		
	CPPUNIT_ASSERT(dataReader->GetPropertyCount() == 1);
	CPPUNIT_ASSERT(STRCASEEQ(dataReader->GetPropertyName(0), L"stitchedRaster"));
	CPPUNIT_ASSERT(dataReader->GetPropertyType(L"stitchedRaster") == FdoPropertyType_RasterProperty);

	// use alias to refer the stitched raster
	FdoPtr<FdoIRaster> raster = dataReader->GetRaster(L"stitchedRaster");

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 16);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Data);

	// MUST contains 1 records
	// verify the bounds
	FdoPtr<FdoFgfGeometryFactory> geomFactory = FdoFgfGeometryFactory::GetInstance();
	FdoPtr<FdoByteArray> ba = raster->GetBounds();
	FdoPtr<FdoIGeometry> geometery = geomFactory->CreateGeometryFromFgf(ba);
	FdoPtr<FdoIEnvelope> bounds = geometery->GetEnvelope();

	CPPUNIT_ASSERT(bounds->GetMinX() == 50.0);
	CPPUNIT_ASSERT(bounds->GetMinY() == 50.0);
	CPPUNIT_ASSERT(bounds->GetMaxX() == 1200.0);
	CPPUNIT_ASSERT(bounds->GetMaxY() == 1004.0);

	// verify the image size
	CPPUNIT_ASSERT(raster->GetImageXSize() == 1150);
	CPPUNIT_ASSERT(raster->GetImageYSize() == 954);

	// read the raster data
	FdoIStreamReader * streamReader = raster->GetStreamReader();
	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(streamReader);	

	FdoByte* buffer = new FdoByte[1150*2+4];

	// read row by row
	FdoInt32 numRead = 0;
	for (int row = 0; row < 954; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buffer, 0, 1150*2+4);
		CPPUNIT_ASSERT(numRead == 1150*2+4);			
	} 
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);


	connection->Close();
}

/// 
/// Test Clip and Mosaic on kGray
/// 
void RfpTestNITF::testClippedMosaic_Gray()
{
	wprintf (L"Testing: %ls\n\n", L"RfpTestNITF::testClippedMosaic_Gray()");
	FdoPtr<FdoIConnection> connection = CreateConnection();
	FdoPtr<FdoIoStream> stream = FdoIoFileStream::Create(L"TestData/NITF/nitf_filters_gray.xml", L"r");
	connection->SetConfiguration(stream);
	connection->Open();

	FdoICommand* cmd = connection->CreateCommand(FdoCommandType_SelectAggregates);
	FdoPtr<FdoISelectAggregates> cmdSelect = static_cast<FdoISelectAggregates*>(cmd);
	cmdSelect->SetFeatureClassName(L"Photo");
	FdoPtr<FdoFilter> filter = FdoRfpUtil::CreateSpatialCondition(L"Image", 
		FdoSpatialOperations_Intersects, 
		FdoRfpRect(orgX + 50, orgY + 50, orgX + 1200, orgY + 1200));
	cmdSelect->SetFilter(filter);

	FdoPtr<FdoIdentifierCollection> propsToSelect = cmdSelect->GetPropertyNames();

	// set up clip function: CLIP(Image, orgX + 50, orgY + 50, orgX + 1000.0, orgY + 1000.0)
	FdoPtr<FdoExpressionCollection> funcParams = FdoExpressionCollection::Create();
	FdoPtr<FdoIdentifier> rasterProp = FdoIdentifier::Create(L"Image");
	funcParams->Add(rasterProp);
	FdoPtr<FdoDataValue> minX = FdoDataValue::Create(orgX + 50, FdoDataType_Double);
	funcParams->Add(minX);
	FdoPtr<FdoDataValue> minY = FdoDataValue::Create(orgY + 50, FdoDataType_Double);
	funcParams->Add(minY);
	FdoPtr<FdoDataValue> maxX = FdoDataValue::Create(orgX + 1200, FdoDataType_Double);
	funcParams->Add(maxX);
	FdoPtr<FdoDataValue> maxY = FdoDataValue::Create(orgY + 1200, FdoDataType_Double);
	funcParams->Add(maxY);
	FdoPtr<FdoFunction> clipFunc = FdoFunction::Create(L"CLIP", funcParams);
	FdoPtr<FdoComputedIdentifier> clipIdentifier = FdoComputedIdentifier::Create(L"clippedRaster", clipFunc );

	// create the nested MOSAIC function that contains CLIP function
	funcParams = FdoExpressionCollection::Create();
	funcParams->Add(clipFunc); // you could add either clipFunc or clipIdentifier here
	FdoPtr<FdoFunction> mosaicFunc = FdoFunction::Create(L"MOSAIC", funcParams);
	FdoPtr<FdoComputedIdentifier> mosaicIdentifier = FdoComputedIdentifier::Create(L"stitchedRaster", mosaicFunc );
	// add it to the properties to select
	propsToSelect->Add(mosaicIdentifier);
	FdoPtr<FdoIDataReader> dataReader = cmdSelect->Execute();

	
	CPPUNIT_ASSERT( dataReader->ReadNext() == true);
		
	CPPUNIT_ASSERT(dataReader->GetPropertyCount() == 1);
	CPPUNIT_ASSERT(STRCASEEQ(dataReader->GetPropertyName(0), L"stitchedRaster"));
	CPPUNIT_ASSERT(dataReader->GetPropertyType(L"stitchedRaster") == FdoPropertyType_RasterProperty);

	// use alias to refer the stitched raster
	FdoPtr<FdoIRaster> raster = dataReader->GetRaster(L"stitchedRaster");

	FdoPtr<FdoRasterDataModel> dataModel = raster->GetDataModel();
	CPPUNIT_ASSERT(dataModel->GetBitsPerPixel() == 8);
	CPPUNIT_ASSERT(dataModel->GetDataModelType() == FdoRasterDataModelType_Gray);

	// MUST contains 1 records
	// verify the bounds
	FdoPtr<FdoFgfGeometryFactory> geomFactory = FdoFgfGeometryFactory::GetInstance();
	FdoPtr<FdoByteArray> ba = raster->GetBounds();
	FdoPtr<FdoIGeometry> geometery = geomFactory->CreateGeometryFromFgf(ba);
	FdoPtr<FdoIEnvelope> bounds = geometery->GetEnvelope();

	CPPUNIT_ASSERT(bounds->GetMinX() == 50.0);
	CPPUNIT_ASSERT(bounds->GetMinY() == 50.0);
	CPPUNIT_ASSERT(bounds->GetMaxX() == 1200.0);
	CPPUNIT_ASSERT(bounds->GetMaxY() == 1024.0);

	// verify the image size
	CPPUNIT_ASSERT(raster->GetImageXSize() == 1150);
	CPPUNIT_ASSERT(raster->GetImageYSize() == 974);

	// read the raster data
	FdoIStreamReader * streamReader = raster->GetStreamReader();
	FdoPtr<FdoIStreamReaderTmpl<FdoByte> > reader = static_cast<FdoIStreamReaderTmpl<FdoByte>*>(streamReader);	

	FdoByte* buffer = new FdoByte[1150+2];

	// read row by row
	FdoInt32 numRead = 0;
	for (int row = 0; row < 974; row++)
	{
		FdoInt32 numRead = reader->ReadNext(buffer, 0, 1150+2);
		CPPUNIT_ASSERT(numRead == 1150+2);			
	} 
	CPPUNIT_ASSERT(reader->ReadNext(buffer, 0, 1) == 0);


	connection->Close();
}
