/*
 * (C) Copyright 2004 by Autodesk, Inc. All Rights Reserved.
 *
 * By using this code, you are agreeing to the terms and conditions of
 * the License Agreement included in the documentation for this code.
 *
 * AUTODESK MAKES NO WARRANTIES, EXPRESS OR IMPLIED, AS TO THE
 * CORRECTNESS OF THIS CODE OR ANY DERIVATIVE WORKS WHICH INCORPORATE
 * IT. AUTODESK PROVIDES THE CODE ON AN "AS-IS" BASIS AND EXPLICITLY
 * DISCLAIMS ANY LIABILITY, INCLUDING CONSEQUENTIAL AND INCIDENTAL
 * DAMAGES FOR ERRORS, OMISSIONS, AND OTHER PROBLEMS IN THE CODE.
 *
 * Use, duplication, or disclosure by the U.S. Government is subject
 * to restrictions set forth in FAR 52.227-19 (Commercial Computer
 * Software Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
 * (Rights in Technical Data and Computer Software), as applicable.
 *
 * Revision Control Modification History
 *
 *         $Id: //providers/RasterFile/src/UnitTest/UnitTest.cpp#33 $
 *     $Author: dalcoup $
 *   $DateTime: 2006/04/06 17:20:15 $
 *     $Change: 12258 $
 *
 */


#include <UnitTest.h>
#include <cppunit/CompilerOutputter.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/XmlOutputter.h>
#include <cppunit/TextOutputter.h>
#include <fstream>
#include <malloc.h>

#include <RfpNoConfigTest.h>
#include <RfpTestExample1.h>
#include <RfpOverridesSerializeTest.h>
#include <RfpTestLogOutputter.h>
#include <RfpTestGetRaster.h>
#include <RfpTestThorough.h>
#include <RfpTestMosaic.h>
#include <RfpTestRasterConversion.h>
#include <RfpTestGeotiff.h>
#include <RfpTestMrSID.h>
#include <RfpTestJp2.h>
#include <RfpTestEcw.h>
#include <RfpTestDem.h>
#include <RfpTestBand.h>
#include <RfpTestBandConfig.h>
#include <RfpTestSpatialContext.h>
#include <RfpTestDted.h>
#include <RfpTestAAIGrid.h>
#include <RfpTestBAIGrid.h>
#include <RfpTestNITF.h>
#include <iostream>


// the default message catalog filename
#ifndef _WIN32
char *fdorfp_cat = "RfpMessage.cat";
#else
char *fdorfp_cat = "RFPMessage.dll";
#endif

// The following macros are used as switches to determine
// which Test Cases will be excuted.

#define TEST_NO_CONFIG
#define TEST_EXAMPLE1
#define TEST_OVERRIDES_SERIALIZE
#define TEST_THOROUGHTEST
#define TEST_GET_RASTER
#define TEST_MOSAIC
#ifdef _WIN32
#define TEST_RASTERCONVERSION
#pragma message ("TODO: Re-enable Dem, Jp2 and Ecw supports on Linux once problems for the tree codecs on Linux are solved .")
#define TEST_DEM
#define TEST_JP2
#define TEST_ECW
#define TEST_DTED
#define TEST_AAIGrid
#define TEST_BAIGrid
#endif
#define TEST_GEOTIFF
#define TEST_BAND
#define TEST_BAND_CONFIG
#define TEST_SPATIAL_CONTEXT
#define TEST_MRSID
#define TEST_NITF


void UnitTestMainProc()
{
	CppUnit::TextUi::TestRunner runner;

#ifdef TEST_NO_CONFIG	
	runner.addTest(RfpNoConfigTest::suite());
#endif

#ifdef TEST_EXAMPLE1
	runner.addTest(RfpTestExample1::suite());
#endif

#ifdef TEST_OVERRIDES_SERIALIZE
	runner.addTest(RfpOverridesSerializeTest::suite());
#endif

#ifdef TEST_GET_RASTER
	runner.addTest(RfpTestGetRaster::suite());
#endif

#ifdef TEST_THOROUGHTEST
	runner.addTest(RfpTestThorough::suite());
#endif

#ifdef TEST_MOSAIC
	runner.addTest(RfpTestMosaic::suite());
#endif

#ifdef TEST_RASTERCONVERSION
	runner.addTest(RfpTestRasterConversion::suite());
#endif

#ifdef TEST_GEOTIFF
	runner.addTest(RfpTestGeotiff::suite());
#endif

#ifdef TEST_MRSID
	runner.addTest(RfpTestMrSID::suite());
#endif

#ifdef TEST_JP2
	runner.addTest(RfpTestJp2::suite());
#endif

#ifdef TEST_ECW
	runner.addTest(RfpTestEcw::suite());
#endif

#ifdef TEST_DEM
	runner.addTest(RfpTestDem::suite());
#endif

#ifdef TEST_BAND
	runner.addTest(RfpTestBand::suite());
#endif

#ifdef TEST_BAND_CONFIG
	runner.addTest(RfpTestBandConfig::suite());
#endif

#ifdef TEST_SPATIAL_CONTEXT
	runner.addTest(RfpTestSpatialContext::suite());
#endif

#ifdef TEST_DTED
	runner.addTest(RfpTestDted::suite());
#endif

#ifdef TEST_AAIGrid
	runner.addTest(RfpTestAAIGird::suite());
#endif

#ifdef TEST_BAIGrid
	runner.addTest(RfpTestBAIGird::suite());
#endif

#ifdef TEST_NITF
	runner.addTest(RfpTestNITF::suite());
#endif

#ifndef LOG_TESTS_RESULT
//#define LOG_TESTS_RESULT
#endif

	// Add other tests here...


#ifdef LOG_TESTS_RESULT
	// save the test results to file.
	std::string fileName = "src/UnitTest/TestLogs/";
	fileName += "RfpLog_";
	fileName += ".xml";
	std::ofstream* logfile = new std::ofstream(fileName.c_str(), std::ios_base::app);
	RfpTestLogOutputter * outputter = new RfpTestLogOutputter(&runner.result(), *logfile);
	runner.setOutputter(outputter);
#endif //LOG_TESTS_RESULT


#ifdef _WIN32
	// Set second parameter to 'true' to check the output result until press <ENTER>.
    LPSTR cmd_line = GetCommandLine ();
    char *tmp = (char*)_alloca (strlen (cmd_line) + 1);
    strcpy (tmp, cmd_line);
    strupr (tmp);
    bool wait = (NULL == strstr (tmp, "-NOWAIT"));

	runner.run("", wait); 
#else
	 runner.setOutputter(new CppUnit::CompilerOutputter(&runner.result(), std
::cerr));
	runner.run("", true); 

#endif
}

void prependTabs(FdoInt32 tabLevel)
{
    for (FdoInt32 i = 0; i < tabLevel; i++)
        wprintf(L"  ");
}

void PrintException(FdoException* exception)
{
	FdoException*	currentException = exception;
	FdoInt32		tabLevel = 0;
	while (currentException != NULL) 
	{
		prependTabs(tabLevel++);
		wprintf(L"%ls\n", currentException->GetExceptionMessage());
		if (currentException != exception)
			currentException->Release();
		currentException = currentException->GetCause();
	}
}

