/*
 * (C) Copyright 2004 by Autodesk, Inc. All Rights Reserved.
 *
 * By using this code, you are agreeing to the terms and conditions of
 * the License Agreement included in the documentation for this code.
 *
 * AUTODESK MAKES NO WARRANTIES, EXPRESS OR IMPLIED, AS TO THE
 * CORRECTNESS OF THIS CODE OR ANY DERIVATIVE WORKS WHICH INCORPORATE
 * IT. AUTODESK PROVIDES THE CODE ON AN "AS-IS" BASIS AND EXPLICITLY
 * DISCLAIMS ANY LIABILITY, INCLUDING CONSEQUENTIAL AND INCIDENTAL
 * DAMAGES FOR ERRORS, OMISSIONS, AND OTHER PROBLEMS IN THE CODE.
 *
 * Use, duplication, or disclosure by the U.S. Government is subject
 * to restrictions set forth in FAR 52.227-19 (Commercial Computer
 * Software Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
 * (Rights in Technical Data and Computer Software), as applicable.
 *
 * Revision Control Modification History
 *
 *         $Id: //Providers/RasterFile/src/UnitTest/RfpTestNITF.h#1 $
 *     $Author: miaoya $
 *   $DateTime: 2005/03/17 19:58:08 $
 *     $Change: 6738 $
 *
 */

#ifndef RfpTestNITF_H
#define RfpTestNITF_H

#ifdef _WIN32
#pragma once
#endif //_WIN32

class RfpTestNITF : public RfpTestCase
{
	GIS_CPPUNIT_DEFINE(testDigitalGlobe);		
	GIS_CPPUNIT_DEFINE(testSpaceImaging1);
	GIS_CPPUNIT_DEFINE(testSpaceImaging2);
	GIS_CPPUNIT_DEFINE(testNGA1);
	GIS_CPPUNIT_DEFINE(testNGA2);
	GIS_CPPUNIT_DEFINE(testNGA3);
	GIS_CPPUNIT_DEFINE(testNGA4);
	GIS_CPPUNIT_DEFINE(testNGA5);
	GIS_CPPUNIT_DEFINE(testNGA6);
	GIS_CPPUNIT_DEFINE(testNGA7);

	GIS_CPPUNIT_DEFINE(testClippedMosaic_Data);
	GIS_CPPUNIT_DEFINE(testClippedMosaic_Gray);

	CPPUNIT_TEST_SUITE(RfpTestNITF);	
	CPPUNIT_TEST(testDigitalGlobe);
	CPPUNIT_TEST(testSpaceImaging1);
	CPPUNIT_TEST(testSpaceImaging2);
	CPPUNIT_TEST(testNGA1);
	CPPUNIT_TEST(testNGA2);
	CPPUNIT_TEST(testNGA3);
	CPPUNIT_TEST(testNGA4);
	CPPUNIT_TEST(testNGA5);
	CPPUNIT_TEST(testNGA6);
	CPPUNIT_TEST(testNGA7);
	CPPUNIT_TEST(testClippedMosaic_Data);
	CPPUNIT_TEST(testClippedMosaic_Gray);
	CPPUNIT_TEST_SUITE_END();

public:
	RfpTestNITF(void);
	~RfpTestNITF(void);

	virtual void _setUp();
	virtual void _tearDown();

	void testDigitalGlobe();
	void testSpaceImaging1();
	void testSpaceImaging2();
	void testNGA1();
	void testNGA2();
	void testNGA3();
	void testNGA4();
	void testNGA5();
	void testNGA6();
	void testNGA7();
	void testClippedMosaic_Data();
	void testClippedMosaic_Gray();
	
};

#endif
