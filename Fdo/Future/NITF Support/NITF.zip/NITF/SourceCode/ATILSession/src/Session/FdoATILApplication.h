/*
 * (C) Copyright 2004 by Autodesk, Inc. All Rights Reserved.
 *
 * By using this code, you are agreeing to the terms and conditions of
 * the License Agreement included in the documentation for this code.
 *
 * AUTODESK MAKES NO WARRANTIES, EXPRESS OR IMPLIED, AS TO THE
 * CORRECTNESS OF THIS CODE OR ANY DERIVATIVE WORKS WHICH INCORPORATE
 * IT. AUTODESK PROVIDES THE CODE ON AN "AS-IS" BASIS AND EXPLICITLY
 * DISCLAIMS ANY LIABILITY, INCLUDING CONSEQUENTIAL AND INCIDENTAL
 * DAMAGES FOR ERRORS, OMISSIONS, AND OTHER PROBLEMS IN THE CODE.
 *
 * Use, duplication, or disclosure by the U.S. Government is subject
 * to restrictions set forth in FAR 52.227-19 (Commercial Computer
 * Software Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
 * (Rights in Technical Data and Computer Software), as applicable.
 *
 * Revision Control Modification History
 *
 *         $Id: //providers/ATILSession/src/Session/FdoATILApplication.h#12 $
 *     $Author: dalcoup $
 *   $DateTime: 2006/04/07 05:20:15 $
 *     $Change: 12258 $
 *
 */

#ifndef FDOATILAPPLICATION_H
#define FDOATILAPPLICATION_H

#ifdef _WIN32
#pragma once
#endif //_WIN32

class FdoATILImagePool;
class FdoATILConfiguration;

class FdoATILApplication
{
//
// Data members
//
private:

#ifdef _WIN32
    static const FdoInt32 m_numSupportedATILCodecs = 22;
#else
    static const FdoInt32 m_numSupportedATILCodecs = 7;
#endif

public:
	static FdoATILImagePool*					m_imagePool;	
	static Atil::ATILSettingsInterface*			m_atilSettings;
    static Atil::ImageFormatCodec*              m_codecs[m_numSupportedATILCodecs];

// 
// Exposed functions
//
public:
	static void InitApplication();
	static void ExitApplication();

	static wchar_t* GetConfigurationFileName();
};

#endif
