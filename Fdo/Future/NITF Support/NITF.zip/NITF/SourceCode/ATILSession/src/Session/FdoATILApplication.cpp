/*
 * (C) Copyright 2004 by Autodesk, Inc. All Rights Reserved.
 *
 * By using this code, you are agreeing to the terms and conditions of
 * the License Agreement included in the documentation for this code.
 *
 * AUTODESK MAKES NO WARRANTIES, EXPRESS OR IMPLIED, AS TO THE
 * CORRECTNESS OF THIS CODE OR ANY DERIVATIVE WORKS WHICH INCORPORATE
 * IT. AUTODESK PROVIDES THE CODE ON AN "AS-IS" BASIS AND EXPLICITLY
 * DISCLAIMS ANY LIABILITY, INCLUDING CONSEQUENTIAL AND INCIDENTAL
 * DAMAGES FOR ERRORS, OMISSIONS, AND OTHER PROBLEMS IN THE CODE.
 *
 * Use, duplication, or disclosure by the U.S. Government is subject
 * to restrictions set forth in FAR 52.227-19 (Commercial Computer
 * Software Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
 * (Rights in Technical Data and Computer Software), as applicable.
 *
 * Revision Control Modification History
 *
 *         $Id: //providers/ATILSession/src/Session/FdoATILApplication.cpp#24 $
 *     $Author: dalcoup $
 *   $DateTime: 2006/04/07 05:20:15 $
 *     $Change: 12258 $
 *
 */

#include <stdafx.h>
#include <FdoATILApplication.h>
#include <FdoATILImagePool.h>
#include <ATILSession/FdoATILConfiguration.h>
#include <FdoATILCacheStrategies.h>
#include <FdoATILGlobals.h>
#include <FdoCommonFile.h>
#include <FdoCommonStringUtil.h>

#ifndef _WIN32
#include <prefix.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#include <TiffFormatCodec.h>
#include <PngFormatCodec.h>
#include <JFIFFormatCodec.h>

#include <Internal/DemFormatCodec.h>
#include <Internal/Jpeg2000FormatCodec.h>
#include <Internal/EcwFormatCodec.h>
#include <Internal/MrSidFormatCodec.h>

#ifdef _WIN32
#include <Internal/DtedFormatCodec.h>
#include <Internal/AAIGridFormatCodec.h>
#include <Internal/BAIGridFormatCodec.h>
#include <Internal/NITFFormatCodec.h>
#include <BmpFormatCodec.h>
#include <CalsFormatCodec.h>
#include <Ig4FormatCodec.h>
#include <PictFormatCodec.h>
#include <RlcFormatCodec.h>
#include <TargaFormatCodec.h>
#include <GifFormatCodec.h>
#include <PcxFormatCodec.h>
#include <FlicFormatCodec.h>
#include <Internal/DoqFormatCodec.h>
#include <GeospotFormatCodec.h>
#endif


using namespace Atil;

FdoATILImagePool*					FdoATILApplication::m_imagePool = NULL;	
Atil::ATILSettingsInterface*		FdoATILApplication::m_atilSettings = NULL;
Atil::ImageFormatCodec*             FdoATILApplication::m_codecs[m_numSupportedATILCodecs];


void FdoATILApplication::InitApplication()
{
	// initialize critical
	Critical::Initialize();
	Critical c;

	static bool bInitialized = false;

	if (bInitialized)
		return;

	//////////////////////////////////////////////////////////////////////////
	// load configuration
	FdoPtr<FdoATILConfiguration> config = FdoATILConfiguration::Create();
	config->Read();

	//////////////////////////////////////////////////////////////////////////
	// init ATIL
    FdoPtr<FdoStringCollection> configFileDirectories = config->GetSwapFileDirectories();

    // if the swap directory exists, add it into the collection
    FdoPtr<FdoStringCollection> swapFileDirectories = FdoStringCollection::Create();
    for (int i = 0; i < configFileDirectories->GetCount(); i++)
    {
        FdoStringP item = configFileDirectories->GetString(i);
        if (FdoCommonFile::IsDirectory(item))
             swapFileDirectories->Add(item);
    }

    if (swapFileDirectories->GetCount() == 0) {
#ifdef _WIN32
         wchar_t tempPath[MAX_PATH + 1];
         if (::GetTempPathW (MAX_PATH, tempPath) != 0 && FdoCommonFile::IsDirectory(tempPath))
             swapFileDirectories->Add(tempPath);
         else
             swapFileDirectories->Add(L"");
#else
        FdoStringP tempPath(L"/tmp/");
        if (!FdoCommonFile::IsDirectory(tempPath))
             swapFileDirectories->Add(L"");
        else 
            swapFileDirectories->Add(tempPath);
#endif
    }

	FdoStringP filePath = swapFileDirectories->GetString(0);
	time_t now;
	time(&now);
	filePath += FdoStringP::Format(FdoATILGlobals::SwapFileNameFormat, (int)now, (int)clock());

	// try catching ATIL exceptions and convert them to Gis exception
    try 
    {
        char* mbFilePath = NULL;
        wide_to_multibyte(mbFilePath, filePath);

        Atil::FileSpecifier fs(StringBuffer((int)(strlen(mbFilePath)+1), (Atil::Byte *) mbFilePath, StringBuffer::kMBCS), FileSpecifier::kFilePath);
        m_atilSettings = newATILSession(fs);

        // append other swap files
        for (int i = 1; i < swapFileDirectories->GetCount(); i++)
        {
            FdoStringP fp = swapFileDirectories->GetString(i);
            fp += FdoStringP::Format(FdoATILGlobals::SwapFileNameFormat, (int)now, (int)clock());

            char* mbFilePath2 = NULL;
            wide_to_multibyte(mbFilePath2, fp);

            Atil::FileSpecifier fs1(StringBuffer((int)(strlen(mbFilePath2)+1), (Atil::Byte *) mbFilePath2, StringBuffer::kMBCS), FileSpecifier::kFilePath);
            m_atilSettings->appendPageFileLocation(fs1);
        }

		m_atilSettings->setTileMemoryLimit(config->GetTileMemoryLimit());
		m_atilSettings->setDelayLoadBehavior(config->GetDelayLoadBehavior() == FdoATILConfiguration::FdoATILDelayLoadBehaviour_Disable ?
			Atil::ATILSettingsInterface::kDisable : (config->GetDelayLoadBehavior() == FdoATILConfiguration::FdoATILDelayLoadBehaviour_Enable ?
			Atil::ATILSettingsInterface::kEnable : Atil::ATILSettingsInterface::kTreatAsDirectLoad));
		m_atilSettings->disableDirectLoad(config->GetDisableDirectLoad());
		m_atilSettings->keepImageFilesOpen(config->GetKeepImageFilesOpen() == FdoATILConfiguration::FdoATILKeepImageFilesOpen_Never ?
			Atil::ATILSettingsInterface::kNever : (config->GetKeepImageFilesOpen() == FdoATILConfiguration::FdoATILKeepImageFilesOpen_Always ?
			Atil::ATILSettingsInterface::kAlways : Atil::ATILSettingsInterface::kMultiResOnly));

		//register the codecs with ATIL

        m_codecs[0] = new TiffFormatCodec();
        m_codecs[1] = new PngFormatCodec();
        m_codecs[2] = new JfifFormatCodec();
		m_codecs[3] = new DemFormatCodec();
        m_codecs[4] = new EcwFormatCodec();
        m_codecs[5] = new Jpeg2000FormatCodec(); 
		m_codecs[6] = new MrSidFormatCodec();
        
#ifdef _WIN32
		m_codecs[7] = new DtedFormatCodec(); 
		m_codecs[8] = new AAIGridFormatCodec(); 
		m_codecs[9] = new BAIGridFormatCodec(); 		
        m_codecs[10] = new CalsFormatCodec();
        m_codecs[11] = new Ig4FormatCodec();
        m_codecs[12] = new PictFormatCodec();
        m_codecs[13] = new RlcFormatCodec();
        m_codecs[14] = new TargaFormatCodec();
        m_codecs[15] = new GifFormatCodec();
        m_codecs[16] = new PcxFormatCodec();
        m_codecs[17] = new FlicFormatCodec();
        m_codecs[18] = new DoqFormatCodec();        
        m_codecs[19] = new GeospotFormatCodec();
        m_codecs[20] = new BmpFormatCodec();
		m_codecs[21] = new NITFFormatCodec(); 
#endif

		for (int i=0; i<m_numSupportedATILCodecs; i++) 
			m_atilSettings->registerFormatCodec(*m_codecs[i]);
	}	
	catch (Atil::ATILException* e)
	{
		std::auto_ptr<Atil::ATILException> spe(e);
		throw FdoException::Create(FdoException::NLSGetMessage(FDO_42_GENERICCHAR, "%1$s", spe->getMessage()->data()));		
	}
	
	//////////////////////////////////////////////////////////////////////////
	// init image pool
	FdoATILICacheStrategy* strategy = NULL;
	switch (config->GetImageCacheStrategy())
	{
	case FdoATILConfiguration::FdoATILImageCacheStrategy_NoCache:
		strategy = new FdoATILNoCache();
		break;
	case FdoATILConfiguration::FdoATILImageCacheStrategy_FIFO:
		strategy = new FdoATILFirstInFirstOut(config->GetImageCacheSize());
		break;
	case FdoATILConfiguration::FdoATILImageCacheStrategy_Memory:
		strategy = new FdoATILMemory(config->GetImageCacheSize() * FdoATILGlobals::Mega);
		break;
	default:
		assert(0);
		break;
	}
	m_imagePool = new FdoATILImagePool();
	m_imagePool->SetCacheStrategy(strategy);
	if (config->GetImageCacheStrategy() != FdoATILConfiguration::FdoATILImageCacheStrategy_NoCache)
	{
		m_imagePool->SetTimeout(config->GetImageCacheTimeout());
		// activate image pool
		m_imagePool->Start();
	}

	//////////////////////////////////////////////////////////////////////////
	// Set the ATIL resource file
#ifdef _WIN32
    AtilFormatCodecLibrary::setResourceFileName(FdoATILGlobals::ATILResourceFileName);
#endif

	bInitialized = true;

	//////////////////////////////////////////////////////////////////////////
	// Set the ATIL resource file
    AtilFormatCodecLibrary::setResourceFileName(FdoATILGlobals::ATILResourceFileName);

}

void FdoATILApplication::ExitApplication()
{


	//////////////////////////////////////////////////////////////////////////
	// uninit image pool
	if (m_imagePool != NULL)
	{
		m_imagePool->Stop();
		delete m_imagePool;
	}

	//////////////////////////////////////////////////////////////////////////
	// uninit ATIL
	// still we should try catching ATIL exceptions
	try
	{
		if (m_atilSettings != NULL)
		{
			deleteATILSession();    
			m_atilSettings = NULL;

			for (int i=0; i<m_numSupportedATILCodecs; i++) 
				delete m_codecs[i];
		}
	}
	catch (Atil::ATILException* e)
	{
		std::auto_ptr<Atil::ATILException> spe(e);
		throw FdoException::Create(FdoException::NLSGetMessage(FDO_42_GENERICCHAR, "%1$s", spe->getMessage()->data()));		
	}

	Critical::Uninitialize();

}

#ifdef _WIN32

extern wchar_t         module[];
extern wchar_t         home_dir[];

wchar_t* getHomeDir ()
{
    return (home_dir);
}

wchar_t* getModule ()
{
    return (module);
}

#else
extern char* getHomeDir();
extern char* getModule ();
#endif


#ifdef _WIN32
#include <malloc.h>
BOOL GetFdoVersion (char* module, char* buffer)
{
    DWORD size;
    DWORD handle;
    void* version;
    VS_FIXEDFILEINFO* info;
    UINT length;
    BOOL ret;

    ret = FALSE;

    if (0 != (size = GetFileVersionInfoSize (module, &handle)))
    {
        version = alloca (size);
        if (0 != (ret = GetFileVersionInfo (module, 0, size, version)))
        {
            if (VerQueryValue (version, "\\", (LPVOID *)&info, &length))
            {
                sprintf (buffer, "%d.%d", info->dwProductVersionMS >> 16, info->dwProductVersionMS & 0xffff);
                ret = TRUE;
            }
        }
    }

    return (ret);
}
#endif


wchar_t* FdoATILApplication::GetConfigurationFileName()
{
    static bool first = true;
    static wchar_t fileName[512];
    
    if (first)
    {
        first = false;
#ifndef _WIN32
        {
			char _fileName[512];
            struct stat my_stat;
            const char *me;
            char *home;
            char *last;
            char *install = "/usr/local/fdo-3.0.0/lib/";

            // try where we are
            me = SELFPATH;
            home = (char*)alloca (strlen (me) + 1);
            strcpy (home, me);
            last = strrchr (home, '/');
            if (NULL != last)
            {
                last++;
                *last = '\0';
            }
            else
                home = "./";
            sprintf (_fileName, "%s%s", home, "FdoATILConfiguration.xml");
            if ((0 != stat (_fileName, &my_stat)) || !S_ISREG(my_stat.st_mode))
                // not found or not a file, try the install location
                if ((0 == stat (install, &my_stat)) && S_ISDIR(my_stat.st_mode))
                    sprintf (_fileName, "%s%s", install, "FdoATILConfiguration.xml");
			mbstowcs(fileName, _fileName, 512);
        }
#else
        {
            // try where we are
            swprintf (fileName, L"%ls%ls", getHomeDir (), L"FdoATILConfiguration.xml");
        }
#endif
    }

    return fileName;

}


